# Phase 9-5B corresponding source

Base: Phase 9-4 source, upstream commit aa5ae93628ef8a44b6f645c8df2c4846c6bad9e5. Only VGA_SetupHandlers case 3, M_TEXT + S3, restores A0000-AFFFF RAM fallback from DOSBox 0.74-3. This is legacy compatibility outside DOS-owned RAM, not a CPU/MCB fix. Other apertures and MMIO override remain intact. CPU/Asyncify instrumentation inherited unchanged.

Use Emscripten 3.1.21, Node 14.18.2, CMake 3.24.2, Ninja 1.11.1. Activate emsdk_env.sh, then:

    emcmake cmake -S . -B build -G Ninja
    cmake --build build --target wdosbox --parallel 4
    cat build/wdosbox.js src/dos/dosbox/ts/worker-server.js > wdosbox.js

Use build/wdosbox.wasm and build/wdosbox.js.symbols together. Paths affect exact output hashes. See launcher scripts/prepare-phase9-5b.mjs and scripts/build-phase9-5b.sh for exact tested paths and patch. No commercial game code/data is included.
