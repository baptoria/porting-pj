# Phase 9-6 corresponding source

Base: Phase 9-5B source, upstream commit aa5ae93628ef8a44b6f645c8df2c4846c6bad9e5. VGA compatibility and Reboot_Handler Asyncify retained. ED4_CPU_TRACE_ENABLED=OFF excludes instruction history/first-event arrays at compile time. Rare EXEC/reboot events remain. On-demand 1/1024 decoder wall-time sampler and read-only counters are not OS thread CPU time.

Use Emscripten 3.1.21, Node 14.18.2, CMake 3.24.2, Ninja 1.11.1. Activate emsdk_env.sh, then:

    emcmake cmake -S . -B build -G Ninja -DED4_CPU_TRACE_ENABLED=OFF
    cmake --build build --target wdosbox --parallel 4
    cat build/wdosbox.js src/dos/dosbox/ts/worker-server.js > wdosbox.js

Use build/wdosbox.wasm and build/wdosbox.js.symbols together. Paths affect exact output hashes. See launcher scripts/prepare-phase9-6.mjs and scripts/build-phase9-6.sh for exact tested paths and patch. No commercial game code/data is included.
