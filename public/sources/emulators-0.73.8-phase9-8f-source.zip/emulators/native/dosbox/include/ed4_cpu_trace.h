// GPL-2.0-or-later. Bounded observation only, no instruction replacement.
#ifndef ED4_CPU_HISTORY_H
#define ED4_CPU_HISTORY_H
#include "dosbox.h"
#if ED4_CPU_TRACE_ENABLED
class ED4_InstructionScope {
  bool owned;
public:
  ED4_InstructionScope(Bitu linear);
  ~ED4_InstructionScope();
};
class ED4_ControlScope {
  bool owned;
public:
  ED4_ControlScope(Bitu mask,Bitu number=0xffffffffu,Bitu type=0);
  ~ED4_ControlScope();
};
Bitu ED4_CPU_Opcode(Bitu opcode,Bitu address32);
void ED4_CPU_ModRM(Bitu modrm);
void ED4_CPU_Defer(void);
void ED4_CPU_End(void);
void ED4_CPU_Boundary(Bitu kind,Bitu detail=0);
void ED4_CPU_CoreBoundary(bool before);
void ED4_CPU_Flush(Bitu reason,Bitu reboot_sequence);
void ED4_CPU_Prepared(Bitu cs,Bitu ip,Bitu ss,Bitu sp,Bitu psp,Bitu mode);
void ED4_CPU_ExecResult(bool success);
#else
// Compile-time removal: no buffers, snapshots, counters, or operand evaluation.
class ED4_InstructionScope { public: explicit ED4_InstructionScope(Bitu) {} };
class ED4_ControlScope { public: ED4_ControlScope(Bitu,Bitu=0xffffffffu,Bitu=0) {} };
inline Bitu ED4_CPU_Opcode(Bitu op,Bitu) { return op; }
inline void ED4_CPU_ModRM(Bitu) {}
inline void ED4_CPU_Defer() {}
inline void ED4_CPU_End() {}
inline void ED4_CPU_Boundary(Bitu,Bitu=0) {}
inline void ED4_CPU_CoreBoundary(bool) {}
inline void ED4_CPU_Flush(Bitu,Bitu) {}
inline void ED4_CPU_Prepared(Bitu,Bitu,Bitu,Bitu,Bitu,Bitu) {}
inline void ED4_CPU_ExecResult(bool) {}
#endif
#endif
