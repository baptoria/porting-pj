# Phase 9-4 corresponding source

Base commit aa5ae93628ef8a44b6f645c8df2c4846c6bad9e5; Asyncify Reboot_Handler retained, BIOS/DOS observation retained; normal-core history and bounded first-event anchors added. No game data.

Use official emsdk **3.1.21** (release a16a8bca2466eb144f7c93fa899c0272c8815dc3), Node 14.18.2, CMake 3.24.2, Ninja 1.11.1. Activate emsdk_env.sh, then in this directory:

    emcmake cmake -S . -B build -G Ninja
    cmake --build build --target wdosbox --parallel 4
    cat build/wdosbox.js src/dos/dosbox/ts/worker-server.js > wdosbox.js

Use build/wdosbox.wasm and build/wdosbox.js.symbols alongside wdosbox.js. Source path strings affect exact output hashes. CMake options are unmodified; compiler SDK is pinned. Full local commands/toolchain provenance: PHASE9_4_FIRST_ANOMALY_REPORT.md in launcher source.
