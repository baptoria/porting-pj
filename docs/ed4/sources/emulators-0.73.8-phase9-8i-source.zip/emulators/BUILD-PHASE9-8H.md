# Phase9-8H
Use Emscripten 3.1.21, Node14.18.2, CMake3.24.2, Ninja.
emcmake cmake -S . -B build -G Ninja -DED4_CPU_TRACE_ENABLED=OFF
cmake --build build --target wdosbox --parallel 4
Append src/dos/dosbox/ts/worker-server.js to build/wdosbox.js.
VGA compatibility and Reboot_Handler Asyncify remain. Only INT66/INT69 CPU_Interrupt and successful DOS INT21/AH3F read events are observed. INT69 AX/BX meaning is unverified. No instruction history, game bytes, audio samples or muting. INT69 IRET returns retained. Exact 9-8B guest tick multiplier retained. H adds speed getter, guest PIC_Ticks output clock and avoids stale blocks on native underrun. See source-changes.json and launcher H report. Starts at 1x.
