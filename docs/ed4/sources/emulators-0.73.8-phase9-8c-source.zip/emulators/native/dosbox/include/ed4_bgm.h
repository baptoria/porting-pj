// GPL-2.0-or-later
#include "dosbox.h"
void ED4_BgmInterrupt(Bitu,Bitu);
void ED4_BgmRead(Bit16u,Bit32u,Bit16u);
